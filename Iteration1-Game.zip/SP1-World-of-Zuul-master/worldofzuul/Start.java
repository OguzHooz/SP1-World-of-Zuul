package worldofzuul;

public class Start {
    public static void main(String[] args) {
        Game start = new Game();
        start.play();
    }
}
